# stitch

A Pen created on CodePen.io. Original URL: [https://codepen.io/Tumi-Gwalo/pen/wvZZdQx](https://codepen.io/Tumi-Gwalo/pen/wvZZdQx).

